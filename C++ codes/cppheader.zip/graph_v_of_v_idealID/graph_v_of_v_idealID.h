#pragma once

/*this function only suits ideal vertex IDs: from 0 to V-1;

this function is for undirected and edge-weighted graph;

idealize vertex IDs is about fast-hashing vertex IDs*/

#include <graph_hash_of_mixed_weighted/graph_hash_of_mixed_weighted_binary_operations.h>

typedef std::vector<std::vector<pair<int, double>>> graph_v_of_v_idealID;


/*

int size = g.size();
			for (int i = 0; i < size; i++) {
				int v_size = g[i].size();
				for (int j = 0; j < v_size; j++) {
					std::cout << "<" << g[i][j].first << "," << g[i][j].second << "> ";
				}
			}

*/


void graph_v_of_v_idealID_add_edge(graph_v_of_v_idealID& g, int e1, int e2, double ec) {

	/*we assume that the size of g is larger than e1 or e2;
	 this function can update edge cost; there will be no redundent edge*/

	graph_hash_of_mixed_weighted_binary_operations_insert(g[e1], e2, ec);
	graph_hash_of_mixed_weighted_binary_operations_insert(g[e2], e1, ec);

}


void graph_v_of_v_idealID_remove_edge(graph_v_of_v_idealID& g, int e1, int e2) {

	/*we assume that the size of g is larger than e1 or e2;
	 this function can update edge cost; there will be no redundent edge*/

	graph_hash_of_mixed_weighted_binary_operations_erase(g[e1], e2);
	graph_hash_of_mixed_weighted_binary_operations_erase(g[e2], e1);

}


bool graph_v_of_v_idealID_contain_edge(graph_v_of_v_idealID& g, int e1, int e2) {

	return graph_hash_of_mixed_weighted_binary_operations_search(g[e1], e2);

}


double graph_v_of_v_idealID_edge_weight(graph_v_of_v_idealID& g, int e1, int e2) {

	return graph_hash_of_mixed_weighted_binary_operations_search_weight(g[e1], e2);

}

double graph_v_of_v_idealID_smallest_adj_edge_weight(graph_v_of_v_idealID& input_graph, int vertex) {

	double smallest_adj_ec = std::numeric_limits<double>::max();

	for (int i = input_graph[vertex].size() - 1; i >= 0; i--) {
		double ec = input_graph[vertex][i].second;
		if (smallest_adj_ec > ec) {
			smallest_adj_ec = ec;
		}
	}

	return smallest_adj_ec;

}



long long int graph_v_of_v_idealID_total_edge_num(graph_v_of_v_idealID& g) {

	int num = 0;
	for (auto it = g.begin(); it != g.end(); it++) {
		num = num + (*it).size();
	}

	return num / 2;

}


graph_v_of_v_idealID graph_v_of_v_idealID_copy_graph(graph_v_of_v_idealID& g) {

	return g;

}


void graph_v_of_v_idealID_print(graph_v_of_v_idealID& g) {

	cout << "graph_v_of_v_idealID_print:" << endl;
	int size = g.size();
	for (int i = 0; i < size; i++) {
		cout << "Vertex " << i << " Adj List: ";
		int v_size = g[i].size();
		for (int j = 0; j < v_size; j++) {
			std::cout << "<" << g[i][j].first << "," << g[i][j].second << "> ";
		}
		cout << endl;
	}
	cout << "graph_v_of_v_idealID_print END" << endl;

}



void test_graph_v_of_v_idealID() {

	int N = 5;
	graph_v_of_v_idealID g(N);

	graph_v_of_v_idealID_add_edge(g, 1, 2, 0.5);
	graph_v_of_v_idealID_add_edge(g, 2, 4, 0.5);
	graph_v_of_v_idealID_add_edge(g, 1, 3, 0.5);
	graph_v_of_v_idealID_add_edge(g, 3, 4, 0.7);
	graph_v_of_v_idealID_add_edge(g, 1, 2, 0.7);

	graph_v_of_v_idealID_print(g);

}





